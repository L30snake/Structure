import UIKit

struct engine {
    var Nissan350z = ""
    var Gtr = ""
    var Gtrskyline = ""
    
    func allengine() -> String {
        return "Thers 3 engines the first is my first car the other two are dream cars Nissan 350z, Nissan Gtr,Nissan Gtr Skyline:" + "\n" + Nissan350z + " " + Gtr + " " + Gtrskyline
}

}

"Nissan 350z = V6"
"Nissan Gtr = V6"
"Nissan Gtr Skyline = 2.6 Liter Twin Turbocharged"

var Allmycars = engine (Nissan350z: "V6", Gtr: "V6", Gtrskyline: "2.6 liter twin turbocharged")

Allmycars.allengine()

print(Allmycars.allengine())
